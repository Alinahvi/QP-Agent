import { LightningElement } from 'lwc';

export default class AgentPanelPlaceholder extends LightningElement {
  // This is a placeholder component with no functionality
}


